
pathCurrDir = pwd;
addpath(genpath([pathCurrDir,'/library']));


