clear all;
close all;
clc;
rng(1);

N = 10;
theta = rand(3,N)*pi;


quatExp(zeros(3,N))
quatExp(theta)