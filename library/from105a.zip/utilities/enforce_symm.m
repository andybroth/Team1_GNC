function A_sym = enforce_symm(A)

A_sym = 0.5*(A+A');

end

